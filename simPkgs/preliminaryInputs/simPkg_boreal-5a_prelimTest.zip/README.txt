This package was successfully tested with the following extensions installed.


C:\Program Files\LANDIS-II-v7\v7\Landis.Extensions.dll
LANDIS-II 2.0
Extensions Administration Tool 2.0
Copyright 2005-2006 University of Wisconsin
Copyright 2011 Portland State University

Extension            Version                Description
---------            -------                -----------
Age-only Succession  5.2                    Succession with age cohorts
Base BDA             4.0.1 (official release) Biological disturbance agents
Base Fire            4.0                    Fire Disturbance
Base Harvest         5.1                    Generic Harvesting for all cohorts
Base Wind            3.1                    Wind Disturbance
Biomass Harvest      4.4                    Harvesting for biomass cohorts
Biomass Succession   5.3                    Succession with biomass cohorts
ForC Succession      3.1                    Forest Carbon Succession with cohorts